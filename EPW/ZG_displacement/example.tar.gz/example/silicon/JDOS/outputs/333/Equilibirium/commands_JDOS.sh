../../../../../../src/JDOS/JDOS_Gaus.x < JDOS_Gaus.in > JDOS_Gaus.out &
